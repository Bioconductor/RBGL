// -*- C++ -*- forwarding header.

#ifndef BOOST_CSTDDEF_HPP
#define BOOST_CSTDDEF_HPP

#if defined(__sgi) && !defined(__GNUC__)
# include <stddef.h>
#else
# include <cstddef>
#endif

#endif
