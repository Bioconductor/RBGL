// preprocessed version of 'boost/mpl/aux_/template_arity.hpp' header
// see the original for copyright information

