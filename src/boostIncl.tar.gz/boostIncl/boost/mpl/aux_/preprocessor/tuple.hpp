//-----------------------------------------------------------------------------
// boost mpl/aux_/preprocessor/tuple.hpp header file
// See http://www.boost.org for updates, documentation, and revision history.
//-----------------------------------------------------------------------------
//
// Copyright (c) 2002
// Aleksey Gurtovoy
//
// Permission to use, copy, modify, distribute and sell this software
// and its documentation for any purpose is hereby granted without fee, 
// provided that the above copyright notice appears in all copies and 
// that both the copyright notice and this permission notice appear in 
// supporting documentation. No representations are made about the 
// suitability of this software for any purpose. It is provided "as is" 
// without express or implied warranty.

#ifndef BOOST_MPL_AUX_PREPROCESSOR_TUPLE_HPP_INCLUDED
#define BOOST_MPL_AUX_PREPROCESSOR_TUPLE_HPP_INCLUDED

#define BOOST_MPL_PP_TUPLE_11_ELEM_0(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e0
#define BOOST_MPL_PP_TUPLE_11_ELEM_1(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e1
#define BOOST_MPL_PP_TUPLE_11_ELEM_2(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e2
#define BOOST_MPL_PP_TUPLE_11_ELEM_3(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e3
#define BOOST_MPL_PP_TUPLE_11_ELEM_4(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e4
#define BOOST_MPL_PP_TUPLE_11_ELEM_5(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e5
#define BOOST_MPL_PP_TUPLE_11_ELEM_6(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e6
#define BOOST_MPL_PP_TUPLE_11_ELEM_7(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e7
#define BOOST_MPL_PP_TUPLE_11_ELEM_8(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e8
#define BOOST_MPL_PP_TUPLE_11_ELEM_9(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e9
#define BOOST_MPL_PP_TUPLE_11_ELEM_10(e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) e10

#endif // BOOST_MPL_AUX_PREPROCESSOR_TUPLE_HPP_INCLUDED
